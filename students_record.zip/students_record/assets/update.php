<?php error_reporting(0);
include("connect.php");
//U-> Update
if(isset($_POST['update'])){
    $error = $msg = "";
    $matric = sanitizeString($_POST['matricNo']);
    $name = sanitizeString($_POST['fullName']);
    $phoneNo = sanitizeString($_POST['phoneNo']);
    $email = sanitizeString($_POST['email']);
    $depart = sanitizeString($_POST['depart']);
    $level = sanitizeString($_POST['level']);
    $check = mysql_query("SELECT * FROM studentsinfo WHERE matricNo = '$matric'", $con);

    if(empty($matric) || empty($name) || empty($phoneNo) || empty($email) || empty($depart) || empty($level)){
        $error .= "Please all fields are required!\n";
    }elseif(!mysql_num_rows($check)>0){
        $error .="You have not register before\n";
    }elseif(!is_string($matric) || strlen($matric)!=13){
        $error .="Invalid matric number!\n";
    }elseif(!is_numeric($phoneNo) || strlen($phoneNo)<11){
        $error .= "Invalid Phone Number\n";
    }else{
        $matric = strtoupper($matric);
        $query = mysql_query("UPDATE studentsinfo  SET matricNo='$matric', fullName = '$name', phoneNo='$phoneNo',
email='$email', department = '$depart', level='$level' WHERE matricNo='$matric'", $con);
        if(mysql_affected_rows($con)) $_SESSION["success"]="Student Record Updated Successfully!";
        else $_SESSION["error"]="Unable to Update Student Record, Please try Again Later!";
        $host  = $_SERVER['HTTP_HOST'];
        $uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
        header("location:http://$host$uri/read.php");
    }
    if(!empty($error))$error="<div class='alert alert-danger fade in small'>
    <a href='#' class='close' data-dismiss='alert'>&times;</a><i class='fa fa-fw fa-warning'></i> <b>$error</b></div>";
    if(!empty($msg))$msg="<div class='alert alert-success fade in small'>
    <a href='#' class='close' data-dismiss='alert'>&times;</a><i class='fa fa-fw fa-check'></i> <b>$msg</b></div>";
}
if(isset($_GET['id']) and !empty($_GET['id'])){
    $upId = $_GET['id'];
    $query = mysql_query("SELECT * FROM studentsinfo WHERE matricNo='$upId'", $con);
    $row ="";
    if($query){
        if(mysql_num_rows($query) > 0){
            $row = mysql_fetch_assoc($query);
        }
    }}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student | Update</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <link href="../css/color.css" rel="stylesheet">
    <link href="../css/font-awesome.css" rel="stylesheet">
    <link href="../css/bootstrap.css" rel="stylesheet">
    <script type="application/javascript" src="../js/jquery-1.11.1.js"></script>
    <script type="application/javascript" src="../js/bootstrap.js"></script>
</head>
<body class="blue lighten-2">
<div class="container">
    <div class="row">
        <div class="col-md-8 col-lg-push-2">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <h4 class="col-md-12 text-center blue-text text-bold">STUDENT'S RECORD</h4>
                    </div>
                </div>
                <ul class="nav nav-pills border-blue b-w-1 lighten-3 blue text-bold">
                    <li><a href="create.php"><i class="fa fa-plus-circle"></i> Create</a> </li>
                    <li><a href="read.php"> <i class="fa fa-table"></i> Read</a></li>
                    <li class="active"><a> <i class="fa fa-pencil-square-o"></i> Update</a></li>
                </ul>
                <div class="panel-body grey lighten-4">
                    <?php echo $msg."\n".$error; ?>
                    <form method="post" id="myform" class="form-horizontal" autocomplete="off">
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input class="form-control input-lg" name="matricNo" id="matricNo" required
                                       value="<?php echo $row['matricNo']?>" placeholder="Enter Your Matric Number">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input class="form-control input-lg" name="fullName" value="<?php echo $row['fullName']?>"
                                       required id="fullName" placeholder="Enter Your Name" >
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="tel" class="form-control input-lg" name="phoneNo" value="<?php echo $row['phoneNo']?>"
                                       required id="phoneNo" placeholder="Enter Your Phone Number" >
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="email" id="email" class="form-control input-lg" name="email" required
                                       placeholder="Enter Your Email Address" value="<?php echo $row['email']?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input id="depart" class="form-control input-lg" name="depart"
                                       required value="<?php echo $row['department']?>" placeholder="Enter Your Department">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input id="level" class="form-control input-lg" name="level" value="<?php echo $row['level']?>"
                                       required placeholder="Enter Your Level" >
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <button id="submit" type="submit" class="btn btn-info btn-lg pull-right" name="update">
                                    Save <i class="fa fa-database"></i></button>
                                <a href="read.php" class="btn btn-danger btn-lg"><i class="fa fa-backward"></i>
                                    Back
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="panel-footer text-center">
                    <font>2022 &copy; Copyright Alright Served</font>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>