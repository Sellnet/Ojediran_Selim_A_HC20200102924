<?php error_reporting(0);
include("connect.php");
//R-> Read
$query = mysql_query("SELECT * FROM studentsinfo", $con);
if($query){
    $data =[];
    if(mysql_num_rows($query) > 0){
        while($row = mysql_fetch_assoc($query) ){ $data[] = $row; } }
}
$msg = "";
if(isset($_GET)){
    $msg = ($_GET=="success")?
        "<div class='alert alert-success fade in'>
    <a href='#' class='close' data-dismiss='alert'>&times;</a><i class='fa fa-fw fa-check'></i><b>Student created successfully</b></div>"
        :"<div class='alert alert-danger fade in '>
    <a href='#' class='close' data-dismiss='alert'>&times;</a><i class='fa fa-fw fa-warning'></i><b>Unable to create student,
    please try again later</b></div>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student | Read</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <link href="../css/color.css" rel="stylesheet">
    <link href="../css/font-awesome.css" rel="stylesheet">
    <link href="../css/bootstrap.css" rel="stylesheet">
    <script type="application/javascript" src="../js/jquery-1.11.1.js"></script>
    <script type="application/javascript" src="../js/bootstrap.js"></script>
</head>
<body class="blue lighten-2">
<div class="container fade in">
    <div class="col-sm-12 rows">
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="row">
                    <h4 class="col-md-12 text-center blue-text text-bold">STUDENT'S RECORD</h4>
                </div>
            </div>
            <ul class="nav nav-pills border-blue b-w-1 lighten-3 blue text-bold">
                <li><a href="create.php"><i class="fa fa-plus-circle"></i> Create</a> </li>
                <li class="active"><a href="read.php"> <i class="fa fa-table"></i> Read</a></li>
            </ul>
            <?php if($_SESSION["success"] !=""){
                $csuccess = $_SESSION["success"];?>
                <div class='alert alert-success fade in'>
                    <a href='#' class='close' data-dismiss='alert'>&times;</a><i class='fa fa-fw fa-check'></i><b>
                        <?php echo htmlentities($csuccess).htmlentities($_SESSION["success"]=""); ?>
                    </b>
                </div>
            <?php }?>
            <?php if($_SESSION["error"] !=""){
                $csuccess = $_SESSION["error"];?>
                <div class='alert alert-danger fade in'>
                    <a href='#' class='close' data-dismiss='alert'>&times;</a><i class='fa fa-fw fa-warning'></i><b>
                        <?php echo htmlentities($csuccess).htmlentities($_SESSION["error"]=""); ?>
                    </b>
                </div>
            <?php }?>
            <div class="panel-body">
                <table class="table table-bordered table-responsive table-hover">
                    <thead>
                    <tr><tr>
                        <th>S / N</th><th>Matriculation Number</th>
                        <th>Full Name</th><th>Phone Number</th>
                        <th>Email</th><th>Department</th>
                        <th>Level</th><th>Update</th>
                        <th>Delete</th>
                    </tr></tr>
                    </thead>
                    <tbody id="userData">
                    <?php if (count($data) > 0){
                        $i=1;
                    foreach($data as $datas){?>
                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?php echo $datas['matricNo'] ?></td>
                        <td><?php echo $datas['fullName'] ?></td>
                        <td><?php echo $datas['phoneNo'] ?></td>
                        <td><?php echo $datas['email'] ?></td>
                        <td><?php echo $datas['department'] ?></td>
                        <td><?php echo $datas['level'] ?></td>
                        <td class="text-center">
                            <a class="btn btn-primary fa fa-pencil-square-o" title="Update"
                               href="update.php?id=<?php echo $datas['matricNo'];?>"></a>
                        </td>
                        <td class="text-center">
                            <form method="get" action="delete.php">
                                <input type="hidden" name="delId" value="<?php echo $datas['matricNo'];?>">
                                <button type="submit" title="Delete" class="btn btn-block btn-danger fa fa-trash-o"
                                        onclick="return confirm('Are you sure to delete this record?')?true:false;"></button>
                            </form></td>
                    </tr>
                    <?php $i++;}}else echo "<tr><td colspan='9'>Record(s) not found...</td></tr>"; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer blue text-center">
                <font size="4"><b>Designed By: Ojediran Selim Adekola. HC20200102924</b></font><br>
                <font size="4">Federal Polytechnic Ede, Osun State.</font><br>
                <font size="4">&copy; Copyright Alright Served</font>
            </div>
        </div>
        </div>
</div>
</body>
</html>