-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Sep 19, 2022 at 02:13 PM
-- Server version: 5.7.28
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `studentsinfo`
--

DROP TABLE IF EXISTS `studentsinfo`;
CREATE TABLE IF NOT EXISTS `studentsinfo` (
  `matricNo` varchar(13) NOT NULL,
  `fullName` varchar(30) NOT NULL,
  `phoneNo` varchar(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `department` varchar(30) NOT NULL,
  `level` varchar(11) NOT NULL,
  PRIMARY KEY (`matricNo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentsinfo`
--

INSERT INTO `studentsinfo` (`matricNo`, `fullName`, `phoneNo`, `email`, `department`, `level`) VALUES
('HC20200102924', 'OJEDIRAN SELIM ADEKOLA', '08076738293', 'ojeselimkola1999@gmail.com', 'COMPUTER SCIENCE', 'HND II'),
('CS20200102001', 'FATAI IYABO', '09076454328', 'fat@gmail.com', 'COMPUTER SCIENCE', 'ND II'),
('CS20200102000', 'ADENLE IJEBU', '07053464789', 'adeolu@yahoo.com', 'COMPUTER SCIENCE', 'ND I'),
('HC20200104893', 'ADEOLA ROKEEB', '08076728293', 'olakewu@gmail.com', 'COMPUTER SCIENCE', 'HND II'),
('HC20200102942', 'SELIM ADEKOLA', '08125456737', 'adekola@gmail.com', 'COMPUTER SCIENCE', 'HND II'),
('HC20200102944', 'Oladunni Sekinat Omolara', '08125456738', 'selim@gmail.com', 'COMPUTER SCIENCE', 'ND II'),
('HC20200102943', 'Omolara Fatia', '07053464789', 'olalekan@gmail.com', 'COMPUTER SCIENCE', 'ND II'),
('HC20200104892', 'ADENLE DOLAPO', '07053464789', 'odunade@gmail.com', 'COMPUTER SCIENCE', 'HND I');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
