<?php
session_start();
$con = mysql_connect('localhost:3308','root','1611Adekola');
if(!$con){
    die("Connection failed! ".mysql_error());
}
$db = mysql_select_db('studentdb', $con);
if(!$db){
    die("Couldn't connect to studentdb ".mysql_error());
}
//function to sanitize data before save to database
function sanitizeString($var){
    global $con;
    $var = strip_tags($var);
    $var = trim($var);
    $var = htmlentities($var);
    return mysql_real_escape_string($var,$con);
}