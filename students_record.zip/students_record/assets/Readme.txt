This assignment is created by OJEDIRAN SELIM ADEKOLA, HC20200102924

This is a basic PHP CRUD Application that handles student information with Mysql Database.
>>> assets folder contain-> php, sql, and text files.
>>> css folder contain-> style sheet used for this assignment.
>>> fonts folder contain-> fontawesome icons used for this assignment
>>> js folder contain-> javascript file using for this assignment

Steps involves are:
1. import studentdb.slq into mysql database.
2. connect.php file contain the connection to the studentdb database.
3. create.php file contain a register form to capture and store the student information to the database.
4. read.php file contain select query and html table to extract all students information from the database.
5. update.php file contain a form to edit and update a student info where matricNo field = a given matriNo to the database.
6. delete.php file contain query that delete student info where matricNo field = a given matriNo.

For more info contact:
08076738293
ojeselimkola1999@gmail.com
https://github.com/Sellnet/Ojediran_Selim_A_HC20200102924

NOTE:
This assignment is for education purpose only not for commercial purpose.