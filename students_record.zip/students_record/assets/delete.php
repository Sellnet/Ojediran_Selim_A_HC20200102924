<?php error_reporting(0);
include("connect.php");
//D-> Delete
if(isset($_GET['delId'])){
    $delId = $_GET['delId'];
    $query = mysql_query("DELETE FROM studentsinfo WHERE matricNo='$delId'", $con);
    if($query) $_SESSION["success"]="Student Record Deleted Successfully!";
    else $_SESSION["error"]="Unable to Delete Student Record, Please try Again Later!";
    $host  = $_SERVER['HTTP_HOST'];
    $uri  = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
    header("location:http://$host$uri/read.php");
}